# Newspaper

Newspaper is a Ghost theme merging old-school newspaper charm with sleek modern design. Ideal for news sites, it embodies traditional journalism with a contemporary, engaging user experience.

&nbsp;

![screenshot-desktop](https://i.imgur.com/mPPx7do.jpg)

&nbsp;

# General Features

* Ghost 5.x ready
* 7 theme presets ([Old Newspaper Light](https://newspaper.kusa-projects.com/?theme-preset=old-newspaper-light), [Modern Newspaper Light](https://newspaper.kusa-projects.com/?theme-preset=modern-newspaper-light), [Old Newspaper Tinted](https://newspaper.kusa-projects.com/?theme-preset=old-newspaper-tinted), [Elegant Newspaper Light](https://newspaper.kusa-projects.com/?theme-preset=elegant-newspaper-light), [Elegant Newspaper Dark](https://newspaper.kusa-projects.com/?theme-preset=elegant-newspaper-dark), [Old Newspaper Dark](https://newspaper.kusa-projects.com/?theme-preset=old-newspaper-dark), [Modern Newspaper Dark](https://newspaper.kusa-projects.com/?theme-preset=modern-newspaper-dark))
* Fully responsive
* Page transition animations
* Compatible with modern browsers
* Regularly updated
* Clean layout and professional design
* Flexible layout options
* Minimal, lightweight and fast
* SEO friendly
* Extensive documentation
* Fast support

# Theme Pages

* [Home page](https://newspaper.kusa-projects.com/)
* [Tag page (Column)](https://newspaper.kusa-projects.com/tag/politics/)
* [Tag page (Simple)](https://newspaper.kusa-projects.com/tag/politics/?tag-layout=simple)
* [Custom tags page](https://newspaper.kusa-projects.com/tags/)
* [Post page (Narrow)](https://newspaper.kusa-projects.com/foreign-relations-diplomatic-talks-with-neighboring-countries/?post-layout=narrow&sidebar=false)
* [Post page (Wide)](https://newspaper.kusa-projects.com/foreign-relations-diplomatic-talks-with-neighboring-countries/?post-layout=wide&sidebar=false)
* [Post page (Featured Image Left)](https://newspaper.kusa-projects.com/foreign-relations-diplomatic-talks-with-neighboring-countries/?post-layout=featured-image-left&sidebar=false)
* [Post page (Featured Image Right)](https://newspaper.kusa-projects.com/foreign-relations-diplomatic-talks-with-neighboring-countries/?post-layout=featured-image-right&sidebar=false)
* [Post page (Narrow With Sidebar)](https://newspaper.kusa-projects.com/foreign-relations-diplomatic-talks-with-neighboring-countries/?post-layout=narrow&sidebar=true)
* [Post page (Wide With Sidebar)](https://newspaper.kusa-projects.com/foreign-relations-diplomatic-talks-with-neighboring-countries/?post-layout=wide&sidebar=true)
* [Post page (Featured Image Left With Sidebar)](https://newspaper.kusa-projects.com/foreign-relations-diplomatic-talks-with-neighboring-countries/?post-layout=featured-image-left&sidebar=true)
* [Post page (Featured Image Right With Sidebar)](https://newspaper.kusa-projects.com/foreign-relations-diplomatic-talks-with-neighboring-countries/?post-layout=featured-image-right&sidebar=true)
* [Post page (Members Only Post)](https://newspaper.kusa-projects.com/innovation-in-the-corporate-world-unveiling-the-latest-business-trends/?post-layout=narrow&sidebar=false)
* [Author page (Column)](https://newspaper.kusa-projects.com/author/john-doe/)
* [Author page (Image Left)](https://newspaper.kusa-projects.com/author/john-doe/?author-layout=author-image-left)
* [Author page (Image Right)](https://newspaper.kusa-projects.com/author/john-doe/?author-layout=author-image-right)
* [Author page (Simple)](https://newspaper.kusa-projects.com/author/katarina-smith-demo/)
* [Custom authors page](https://newspaper.kusa-projects.com/authors/)
* [Custom membership page](https://newspaper.kusa-projects.com/membership/)
* [Custom archive page](https://newspaper.kusa-projects.com/archive/)
* [Custom contact page](https://newspaper.kusa-projects.com/contact/)
* [Custom FAQ page](https://newspaper.kusa-projects.com/faq/)
* [Custom sign-in page](https://newspaper.kusa-projects.com/signin/)
* [Custom sign-up page](https://newspaper.kusa-projects.com/signup/)
* [Custom subscribe page](https://newspaper.kusa-projects.com/subscribe/)
* [Custom account page (All Data)](https://newspaper.kusa-projects.com/demo-account/)
* [Custom account page (All Data No Button)](https://newspaper.kusa-projects.com/demo-account/?no-subscribe-button=true)
* [Custom account page (Simple)](https://newspaper.kusa-projects.com/demo-account/?account-layout=simple)
* [Custom account page (Simple No Button)](https://newspaper.kusa-projects.com/demo-account/?account-layout=simple&no-subscribe-button=true)
* [Custom 404 page](https://newspaper.kusa-projects.com/404/)

# Other Features

* Translation ready (English included)
* Custom setting for background color
* Custom setting for text color
* Content that scales with device width
* Scale factor for devices larger than 1920px
* Custom setting for primary, secondary, tertiary and quartary fonts (Google Fonts)
* Custom setting for pages (All Custom Pages, Only Account Pages or None)
* Custom setting for Social Urls (Facebook, Twitter/X, Instagram, Linkedin, Pinterest)
* Different Announcement bar types (Moving Several News, Moving One News, Static or Normal)
* Different Heading Styles (Uppercase, Lowercase, Caapitalize or none)
* Custom Setting for Image style (Normal, Grayscale or Tinted)
* Custom setting for Initials
* Newsletter in latest posts section and post sidebar
* Custom setting for Featured tags sections on home page
* 2 Tag page layouts (Column or Simple)
* 4 Author page layouts (Column, Author Image Left, Author Image Right or Simple)
* 4 Account page layouts (All Data Layout, All Data Layout No Button, Simple Layout or Simple Layout No Button)
* Lazy loading images animation
* Logo Scale
* Publication title, description, icon and logo
* Custom navigation menu with animations that supports level 2 links
* Default Ghost search
* Posts and tags are lazy loaded
* Latest posts section on home page
* Custom featured posts on home page
* Grid with posts, authors and tags
* Posts with truncated excerpt
* Animated Footer that supports level 2 links
* Newsletter input in the Footer
* Social links in Footer and Navbar (Facebook, Twitter/X, Linkedin, Instagram, Pinterest)
* 4 post layouts (Wide, Narrow, Featured Image Left or Featured Image Right)
* Custom setting for Sidebar on post page
* Custom setting for Sidebar content (Featured Articles or Table of Contents)
* Custom setting for Sidebar position (Left or Right)
* Multiple authors with reading time and date
* Responsive images (full-width, regular, narrow, image with link, image from Unsplash) with captions
* Image gallery
* Image zoom in post view
* Styled texts: Headings (h1 - h6), bold text, italized text, links
* Styled unordered and ordered lists, 2 quote types, responsive tables, custom divider
* Custom bookmark, button (CTA), callout, product card, file card, upload card, video card (Youtube, Vimeo, Custom), signup card
* Responsive video (full-width, regular or narrow)
* Responsive header cards
* Supports Spotify, Twitter, Soundcloud and Codepen embeds
* Custom Toggle card
* Share links on post page (Facebook, Twitter, Linkedin, URL)
* Comments section with custom styles
* Custom next or previous post section at the end of post page
* Author page with author image, name, bio, location, socials (Facebook, Twitter, personal website) and posts
* Membership page with custom heading, tab section for membership tiers (yearly nad monthly)
* Custom currencies
* Contact page with heading and description, [Formspree](https://formspree.io/) form
* Custom FAQ page with toggle cards
* Custom signin, signup and subsribe pages
* Custom account page with account details
* Custom archive page with filtered posts by tag name
* Custom 404 page with home page link

# Documentation

To access the documentation, please visit the following link: [Documentation](https://www.kusa-projects.com/newspaper-documentation)

# Support

To contact us, please use the following link: [Contact](https://www.kusa-projects.com/contact) or send us a message on e-mail `kusaprojects.agency@gmail.com`

# Copyright & License

The Newspaper theme is licensed for a single-use per purchase. Each theme license allows you to use the theme for one website or web page. If you wish to use the theme for multiple websites or web pages, you will need to purchase additional licenses accordingly. Redistribution, reselling, or sublicensing of the theme is strictly prohibited.




